//
//  ViewController.swift
//  ctquizz
//
//  Created by Maxime Lebreton on 07/01/2021.
//

import UIKit

class ViewController: UIViewController {
    var meilleurScore = 0
    @IBOutlet weak var displayBestScore: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        displayBestScore.text = "MeilleurScore : " + String(meilleurScore)
        // Do any additional setup after loading the view.
    }
    
    @IBAction func save(_ unwindSegue: UIStoryboardSegue) {
        if let vc = unwindSegue.source as? QuizzViewController {
            meilleurScore = vc.meilleurScore
        }
        displayBestScore.text = "Meilleur score : " + String(meilleurScore)
        // Use data from the view controller which initiated the unwind segue
    }
}

