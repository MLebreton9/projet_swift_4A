//
//  ThemeViewController.swift
//  ctquizz
//
//  Created by Maxime Lebreton on 28/01/2021.
//

import UIKit

class ThemeViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    var listTheme : [String] = []
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listTheme.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: UITableViewCell = themeTableView.dequeueReusableCell(withIdentifier: "themeCell", for : indexPath) 
        cell.textLabel?.text = listTheme[indexPath.row]
        return cell
    }
    
    @IBOutlet weak var themeTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        if let path = Bundle.main.path(forResource: "quizz8", ofType: "txt") {
            do {
                print(path)
                let data = try String(contentsOfFile: path, encoding: .utf8)
                let myStrings = data.components(separatedBy: .newlines)
                print("MyStrings.count" + String(myStrings.count))
                var alreadyFound : Bool = false
                for i in 0..<myStrings.count {
                    if i % 14 == 0 {
                        for j in listTheme {
                            if j == myStrings[i] {
                                alreadyFound = true
                            }
                        }
                        if (!alreadyFound){
                            listTheme.append(myStrings[i])
                        }
                    }
                    alreadyFound = false
                }
                
            }
            catch {
                print(error)
            }        // Do any additional setup after loading the view.
        }
        for i in 0...listTheme.count-1 {
            print(listTheme[i])
        }
        themeTableView.dataSource = self
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
}


