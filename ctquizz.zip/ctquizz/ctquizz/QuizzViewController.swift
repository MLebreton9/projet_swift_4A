//
//  QuizzViewController.swift
//  ctquizz
//
//  Created by Maxime Lebreton on 13/01/2021.
//

import UIKit

class QuizzViewController: UIViewController {

    
    @IBOutlet weak var textQuestion: UILabel!
    @IBOutlet weak var textTheme: UILabel!
    @IBOutlet weak var displayScore: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        displayScore.text = String(score)
        changeQuestion()
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    @IBOutlet var answerCollection: [UIButton]!
    
    //var listQuestions = ["Question1", "Question2", "Question3", "Question4", "Question5", "Question6", "Question7", "Question8", "Question9", "Question10"]
      
    
    
    
    var good = 0
    var perdu = false
    var score = 0
    var meilleurScore = 0
    
    @IBAction func answerCheck(_ sender: UIButton) {
        
        if (!perdu){
            if sender.tag == good {
                score = score + 1
                displayScore.text = String(score)
                changeQuestion()
            }
            else {
                sender.backgroundColor = UIColor.red
                for a in answerCollection{
                    if a.tag == good {
                        a.backgroundColor = UIColor.green
                    }
                }
                textQuestion.text = "Perdu"
                perdu = true
                if score > meilleurScore {
                    meilleurScore = score
                }
            }
        }
        
    }
    
    func changeQuestion() {
        //let randomQuestion = Int.random(in: 0...listQuestions.count-1)
        //textQuestion.text = listQuestions[randomQuestion]
        //var question : [String]
        if let path = Bundle.main.path(forResource: "quizz8", ofType: "txt") {
            do {
                print(path)
                let data = try String(contentsOfFile: path, encoding: .utf8)
                let myStrings = data.components(separatedBy: .newlines)
                print("MyStrings.count" + String(myStrings.count))
                let random = Int.random(in: 0...myStrings.count)
                let choix = Int((random/14) * 14)
                for i in 0..<myStrings.count {
                    print(String(i) + " : " + myStrings[i])
                }
                print("Random" + String(random))
                print("Choix" + String(choix))
                textTheme.text = myStrings[choix]
                textQuestion.text = myStrings[choix + 2]
                let bonneRep = myStrings[choix + 4]
                var reponses : [String] = []
                for i in [4, 6, 8, 10] {
                    reponses.append(myStrings[choix + i])
                    print(String(i) + " : " + myStrings[choix + i])
                }
                reponses.shuffle()
                for i in 0...3 {
                    if reponses[i] == bonneRep {
                        good = i
                    }
                }
                for a in answerCollection {
                    a.setTitle(reponses[a.tag], for: .normal)
                }
                for a in answerCollection {
                    a.backgroundColor = UIColor.systemGray5
                }
            }
            catch {
                print(error)
            }
        }
        else{
            print("No File")
        }
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let vc = segue.destination as? ViewController {
            vc.meilleurScore = meilleurScore
        }
    }
}
